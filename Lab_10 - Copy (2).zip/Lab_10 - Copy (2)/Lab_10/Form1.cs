﻿using Emgu.CV;
using Emgu.CV.CvEnum;
using Emgu.CV.Structure;
using Emgu.CV.Util;
using System;
using System.Drawing;
using System.IO.Ports;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Lab_10
{
    public partial class Form1 : Form
    {
        VideoCapture _capture;
        Thread _captureThread;
        //variables for Serial Communication
        int xCoord;
        int yCoord;
        int shapeType;
        //Setup for Serial Communication with arduino
        SerialPort arduinoSerial = new SerialPort();
        bool enableCoordinateSending = false;
        Thread serialMonitoringThread;
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            // create the capture object and processing thread
            _capture = new VideoCapture(1);
            _captureThread = new Thread(ProcessImage);
            _captureThread.Start();
            try
            {
                //Sees if it can communicate between the arduino and the laptop
                arduinoSerial.PortName = "COM9";
                arduinoSerial.BaudRate = 9600;
                arduinoSerial.Open();
                serialMonitoringThread = new Thread(MonitorSerialData);
                serialMonitoringThread.Start();
                xInput.Text = "0";
                yInput.Text = "0";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Initializing COM port");
                Close();
            }
        }

        private void ProcessImage()
        {
            while (_capture.IsOpened)
            {
                // frame maintenance
                Mat sourceFrame = _capture.QueryFrame();
                // resize to PictureBox aspect ratio
                int newHeight = (sourceFrame.Size.Height * sourcePictureBox.Size.Width) / sourceFrame.Size.Width;
                Size newSize = new Size(sourcePictureBox.Size.Width, newHeight);
                CvInvoke.Resize(sourceFrame, sourceFrame, newSize);
                // display the image in the source PictureBox
                sourcePictureBox.Image = sourceFrame.Bitmap;
                //finds the x-axis max coordinate and the y-axis max coordinate based on the frame size
                Invoke(new Action(() =>
                {
                    matTextBoxX.Text = Convert.ToString(sourceFrame.Size.Width);
                    matTextBoxY.Text = Convert.ToString(sourceFrame.Size.Height);
                }));
                // copy the source image so we can display a copy with artwork without editing the original:
                Mat grayFrame = new Mat();
                CvInvoke.CvtColor(sourceFrame, grayFrame, Emgu.CV.CvEnum.ColorConversion.Bgr2Gray);
                Mat sourceFrameWithArt = sourceFrame.Clone();
                // create an image version of the source frame, will be used when focusing the image
                Image<Bgr, byte> sourceFrameFocused = sourceFrame.ToImage<Bgr, byte>();
                // Isolating the ROI: convert to a gray, apply binary threshold:
                Image<Gray, byte> grayImg = sourceFrame.ToImage<Gray, byte>().ThresholdBinary(new Gray(125), new Gray(255));
                using (VectorOfVectorOfPoint contours = new VectorOfVectorOfPoint())
                {
                    // Build list of contours
                    CvInvoke.FindContours(grayImg, contours, null, RetrType.List, ChainApproxMethod.ChainApproxSimple);
                    // Selecting the most relevant contours
                    if (contours.Size > 0)
                    {
                        double maxArea = 0;
                        int chosen = 0;
                        for (int i = 0; i < contours.Size; i++)
                        {
                            VectorOfPoint contour = contours[i];
                            double area = CvInvoke.ContourArea(contour);

                            maxArea = area;
                            //chosen = i;

                        }
                        // Getting minimal rectangle which contains the contour
                        Rectangle boundingBox = CvInvoke.BoundingRectangle(contours[chosen]);
                        // Draw on the display frame
                        if (maxArea != 0)
                            MarkDetectedObject(sourceFrameWithArt, contours[chosen], boundingBox, maxArea);
                        // Create a slightly larger bounding rectangle, we'll set it as the ROI for focus NOT WARPING
                        sourceFrameFocused.ROI = new Rectangle((int)Math.Min(0, boundingBox.X - 30),
                        (int)Math.Min(0, boundingBox.Y - 30),
                        (int)Math.Max(sourceFrameFocused.Width - 1, boundingBox.X +
                        boundingBox.Width + 30),
                        (int)Math.Max(sourceFrameFocused.Height - 1, boundingBox.Y +
                        boundingBox.Height + 30));
                        // Display the version of the source image with the added artwork, simulating ROI focus:
                        roiPictureBox.Image = sourceFrameWithArt.Bitmap;
                        // Draws on the frame and shows the mid point
                        focusedPictureBox.Image = FocusImage(sourceFrameFocused, contours[chosen]).Bitmap;
                        //determines the number of corners for the detected shape
                        int cornerCount = countCorners(contours[chosen]);
                        if (cornerCount == 3)
                        {
                            Point labelPoint = new Point();
                            //sets the mid point as label before it's split up and sent over serially
                            labelPoint = getMidPoint(contours[chosen]);
                            xCoord = labelPoint.X;
                            yCoord = labelPoint.Y;
                            //determines what shape it is false is a triangle
                            shapeType = 0;
                            Invoke(new Action(() =>
                            {
                                testerLabel.Text = $"The triangle's middle Point Coordinate is ( {labelPoint.X}, {labelPoint.Y} ) ";
                            }));
                        }
                        else if (cornerCount == 4)
                        {
                            Point labelPoint = new Point();
                            //sets the mid point as label before it's split up and sent over serially
                            labelPoint = getMidPoint(contours[chosen]);
                            xCoord = labelPoint.X;
                            yCoord = labelPoint.Y;
                            //determines what shape it is truth is a square
                            shapeType = 1;
                            Invoke(new Action(() =>
                            {
                                testerLabel.Text = $"The square's middle Point Coordinate is ( {labelPoint.X}, {labelPoint.Y} ) ";
                            }));
                        }
                        //continues the process of back and forth serial communication once the enableCoordinateSending is true
                        if (enableCoordinateSending && (cornerCount == 3 || cornerCount == 4))
                        {
                            stageCoordinates();
                            sendCoordinates();
                            
                        }
                    }

                }
            }
        }

        //countCorners determines the number of corners for a detected shape and returns an int
        private static int countCorners(VectorOfPoint contour)
        {
            int corners = 0;
            using (VectorOfPoint approxContour = new VectorOfPoint())
            {
                CvInvoke.ApproxPolyDP(contour, approxContour, CvInvoke.ArcLength(contour, true) * 0.05, true);
                // get an array of points in the contour
                Point[] points = approxContour.ToArray();
                if (points.Length == 3)
                {
                    corners = 3;
                }
                if (points.Length == 4)
                {
                    corners = 4;
                }
            }

            return corners;
        }

        //getCoordinates finds the mid point of the detect shape and returns as a point to be split up for serial communication
        private static Point getMidPoint(VectorOfPoint contour)
        {
            Point midPoint = new Point();
            using (VectorOfPoint approxContour = new VectorOfPoint())
            {
                CvInvoke.ApproxPolyDP(contour, approxContour, CvInvoke.ArcLength(contour, true) * 0.05, true);
                // get an array of points in the contour
                Point[] points = approxContour.ToArray();
                if (points.Length == 3)
                {
                    int holder = points.Length;
                    holder--;
                    Point sideMidPoint = new Point(((points[holder].X + points[0].X) / 2), ((points[holder].Y + points[0].Y) / 2));
                    holder--;

                    midPoint = new Point(sideMidPoint.X, (points[1].Y + points[0].Y) / 2);
                }
                else if (points.Length == 4)
                {
                    int holder = points.Length;
                    holder--;
                    Point leftSideMidPoint = new Point(((points[holder].X + points[0].X) / 2), ((points[holder].Y + points[0].Y) / 2));
                    holder--;
                    Point rightSideMidPoint = new Point(((points[holder].X + points[1].X) / 2), ((points[holder].Y + points[1].Y) / 2));
                    midPoint = new Point(((rightSideMidPoint.X + leftSideMidPoint.X) / 2), rightSideMidPoint.Y);
                }
            }

            return midPoint;
        }

        //detects the shape based on the contours found and they draws on the frame to mark/find the mid point
        private static Image<Bgr, Byte> FocusImage(Image<Bgr, byte> frame, VectorOfPoint contour)
        {
            using (VectorOfPoint approxContour = new VectorOfPoint())
            {
                CvInvoke.ApproxPolyDP(contour, approxContour, CvInvoke.ArcLength(contour, true) * 0.05, true);
                // get an array of points in the contour
                Point[] points = approxContour.ToArray();
                int t = 0;
                Point ph = new Point();
                for (int i = 0; i < points.Length; i++)
                {
                    //sets the same points in the same position every time
                    if (points[t].X < points[i].X)
                    {
                        ph = points[t];
                        points[t] = points[i];
                        points[i] = ph;

                    }
                }
                for (int i = 0; i < points.Length; i++)
                {
                    frame.Draw(new CircleF(points[i], 5), new Bgr(Color.Red), 5);
                }
                if (points.Length == 3)
                {
                    int holder = points.Length;
                    holder--;
                    Point leftSidePoint = new Point(((points[holder].X + points[0].X) / 2), ((points[holder].Y + points[0].Y) / 2));
                    frame.Draw(new CircleF(leftSidePoint, 5), new Bgr(Color.Yellow), 5);
                    Point rightSidePoint = new Point(((points[holder].X + points[1].X) / 2), ((points[holder].Y + points[1].Y) / 2));
                    frame.Draw(new CircleF(rightSidePoint, 5), new Bgr(Color.Green), 5);
                    frame.Draw(new CircleF(points[holder], 5), new Bgr(Color.Orange), 5);
                    Point midPoint;
                    if (points[holder].Y < points[0].Y)
                        midPoint = new Point(((rightSidePoint.X + leftSidePoint.X) / 2), leftSidePoint.Y);
                    else
                        midPoint = new Point(((rightSidePoint.X + points[0].X) / 2) - 2, rightSidePoint.Y);

                    frame.Draw(new CircleF(midPoint, 5), new Bgr(Color.Purple), 5);
                }
                else if (points.Length == 4)
                {
                    int holder = points.Length;
                    holder--;
                    Point leftSidePoint = new Point(((points[holder].X + points[0].X) / 2), ((points[holder].Y + points[0].Y) / 2));
                    holder--;
                    Point rightSidePoint = new Point(((points[holder].X + points[1].X) / 2), ((points[holder].Y + points[1].Y) / 2));
                    Point midPoint = new Point();
                    midPoint = new Point(rightSidePoint.X, (rightSidePoint.Y + leftSidePoint.Y) / 2);
                    
                    frame.Draw(new CircleF(midPoint, 5), new Bgr(Color.Purple), 5);
                }
                return frame;
            }
        }

        // Creates the bounding box the enclosed the shape to help determining the proper contours and determines the shape's area
        private static void MarkDetectedObject(Mat frame, VectorOfPoint contour, Rectangle boundingBox, double area)
        {
            // Drawing contour and box around it
            CvInvoke.Polylines(frame, contour, true, new Bgr(Color.Red).MCvScalar);
            CvInvoke.Rectangle(frame, boundingBox, new Bgr(Color.Red).MCvScalar);
            // Write information next to marked object
            Point center = new Point(boundingBox.X + boundingBox.Width / 2, boundingBox.Y + boundingBox.Height / 2);
            var info = new string[] { $"Area: {area}", $"Position: {center.X}, {center.Y}" };
            WriteMultilineText(frame, info, new Point(center.X, boundingBox.Bottom + 12));
        }

        //Writes the text on the given image in this case it's the bounding box and area size of the shape
        private static void WriteMultilineText(Mat frame, string[] lines, Point origin)
        {
            for (int i = 0; i < lines.Length; i++)
            {
                int y = i * 10 + origin.Y; // Moving down on each line
                CvInvoke.PutText(frame, lines[i], new Point(origin.X, y),
                FontFace.HersheyPlain, 0.8, new Bgr(Color.Red).MCvScalar);
            }
        }
        
        //stageCoordinates setups the proper x value y value and shape type into a text box so that it can be sent serially
        private void stageCoordinates()
        {
            Invoke(new Action(() =>
            {
                xInput.Text = Convert.ToString(xCoord);
                yInput.Text = Convert.ToString(yCoord);
                shapeTextBox.Text = Convert.ToString(shapeType);
            }));
        }
        //sendCoordinates turns the serial variables into bytes and sends them to the arduino
        private void sendCoordinates()
        {
            if (!enableCoordinateSending)
            {
                MessageBox.Show("Temporarily locked...");
                return;
            }
            int x = -1;
            int y = -1;
            int r = -1;
            if (int.TryParse(xInput.Text, out x) && int.TryParse(yInput.Text, out y) && int.TryParse(shapeTextBox.Text, out r))
            {
                byte[] buffer = new byte[5] {
                Encoding.ASCII.GetBytes("<")[0],
                Convert.ToByte(r),
                Convert.ToByte(x),
                Convert.ToByte(y),
                Encoding.ASCII.GetBytes(">")[0]
                };
                arduinoSerial.Write(buffer, 0, 5);
                enableCoordinateSending = false;
            }
            else
            {
                MessageBox.Show("X and Y values must be integers", "Unable to parse coordinates");
            }
        }
        
        

        //MonitorSerialData listens to the arduino and waits for it to send information back to the laptop
        private void MonitorSerialData()
        {
            while (true)
            {
                // block until \n character is received, extract command data
                string msg = arduinoSerial.ReadLine();
                // confirm the string has both < and > characters
                if (msg.IndexOf("<") == -1 || msg.IndexOf(">") == -1)
                {
                    continue;
                }
                // remove everything before (and including) the < character
                msg = msg.Substring(msg.IndexOf("<") + 1);
                // remove everything after (and including) the > character
                msg = msg.Remove(msg.IndexOf(">"));
                // if the resulting string is empty, disregard and move on
                if (msg.Length == 0)
                {
                    continue;
                }
                // parse the command
                if (msg.Substring(0, 1) == "S")
                {
                    // command is to suspend, toggle states accordingly:
                    ToggleFieldAvailability(msg.Substring(1, 1) == "1");
                }
                else if (msg.Substring(0, 1) == "P")
                {
                    // command is to display the point data, output to the text field:
                    Invoke(new Action(() =>
                    {
                        returnedPointLbl.Text = $"Returned Point Data: {msg.Substring(1)}";
                    }));
                }
            }
        }

        //ToggleFieldAvailability sets a label to let the user know when the arduino is taking in new information or not
        private void ToggleFieldAvailability(bool suspend)
        {
            Invoke(new Action(() =>
            {
                enableCoordinateSending = !suspend;
                lockStateToolStripStatusLabel.Text = $"State: {(suspend ? "Locked" : "Unlocked")}";
            }));
        }
        
        //sendBtn_Click starts the autonomous part of the application once it sents enableCoordinateSending
        private void sendBtn_Click(object sender, EventArgs e)
        {
            enableCoordinateSending = true;
            sendCoordinates();
        }

        //setXYBtn runs the stageCoordinates function
        private void setXYBtn_Click(object sender, EventArgs e)
        {
            stageCoordinates();
        }

       //Function for closing the application
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            // terminate the image processing thread to avoid orphaned processes
            _captureThread.Abort();
            serialMonitoringThread.Abort();
        }
    }
}
