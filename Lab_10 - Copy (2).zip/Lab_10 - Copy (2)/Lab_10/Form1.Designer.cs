﻿namespace Lab_10
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.testerLabel = new System.Windows.Forms.Label();
            this.focusedPictureBox = new System.Windows.Forms.PictureBox();
            this.roiPictureBox = new System.Windows.Forms.PictureBox();
            this.sourcePictureBox = new System.Windows.Forms.PictureBox();
            this.lockStateToolStripStatusLabel = new System.Windows.Forms.Label();
            this.returnedPointLbl = new System.Windows.Forms.Label();
            this.sendBtn = new System.Windows.Forms.Button();
            this.yInput = new System.Windows.Forms.TextBox();
            this.xInput = new System.Windows.Forms.TextBox();
            this.yLabel = new System.Windows.Forms.Label();
            this.xLabel = new System.Windows.Forms.Label();
            this.setXYBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.shapeTextBox = new System.Windows.Forms.TextBox();
            this.matTextBoxX = new System.Windows.Forms.TextBox();
            this.matTextBoxY = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.focusedPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roiPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sourcePictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // testerLabel
            // 
            this.testerLabel.AutoSize = true;
            this.testerLabel.Location = new System.Drawing.Point(594, 232);
            this.testerLabel.Name = "testerLabel";
            this.testerLabel.Size = new System.Drawing.Size(46, 17);
            this.testerLabel.TabIndex = 7;
            this.testerLabel.Text = "label1";
            // 
            // focusedPictureBox
            // 
            this.focusedPictureBox.Location = new System.Drawing.Point(763, 12);
            this.focusedPictureBox.Name = "focusedPictureBox";
            this.focusedPictureBox.Size = new System.Drawing.Size(211, 192);
            this.focusedPictureBox.TabIndex = 6;
            this.focusedPictureBox.TabStop = false;
            // 
            // roiPictureBox
            // 
            this.roiPictureBox.Location = new System.Drawing.Point(502, 12);
            this.roiPictureBox.Name = "roiPictureBox";
            this.roiPictureBox.Size = new System.Drawing.Size(211, 192);
            this.roiPictureBox.TabIndex = 5;
            this.roiPictureBox.TabStop = false;
            // 
            // sourcePictureBox
            // 
            this.sourcePictureBox.Location = new System.Drawing.Point(236, 12);
            this.sourcePictureBox.Name = "sourcePictureBox";
            this.sourcePictureBox.Size = new System.Drawing.Size(211, 192);
            this.sourcePictureBox.TabIndex = 4;
            this.sourcePictureBox.TabStop = false;
            // 
            // lockStateToolStripStatusLabel
            // 
            this.lockStateToolStripStatusLabel.AutoSize = true;
            this.lockStateToolStripStatusLabel.Location = new System.Drawing.Point(36, 128);
            this.lockStateToolStripStatusLabel.Name = "lockStateToolStripStatusLabel";
            this.lockStateToolStripStatusLabel.Size = new System.Drawing.Size(45, 17);
            this.lockStateToolStripStatusLabel.TabIndex = 24;
            this.lockStateToolStripStatusLabel.Text = "State:";
            // 
            // returnedPointLbl
            // 
            this.returnedPointLbl.AutoSize = true;
            this.returnedPointLbl.Location = new System.Drawing.Point(36, 219);
            this.returnedPointLbl.Name = "returnedPointLbl";
            this.returnedPointLbl.Size = new System.Drawing.Size(141, 17);
            this.returnedPointLbl.TabIndex = 23;
            this.returnedPointLbl.Text = "Returned Point Data:";
            // 
            // sendBtn
            // 
            this.sendBtn.Location = new System.Drawing.Point(39, 169);
            this.sendBtn.Name = "sendBtn";
            this.sendBtn.Size = new System.Drawing.Size(132, 25);
            this.sendBtn.TabIndex = 22;
            this.sendBtn.Text = "Send Coordinates";
            this.sendBtn.UseVisualStyleBackColor = true;
            this.sendBtn.Click += new System.EventHandler(this.sendBtn_Click);
            // 
            // yInput
            // 
            this.yInput.Location = new System.Drawing.Point(64, 80);
            this.yInput.Name = "yInput";
            this.yInput.Size = new System.Drawing.Size(100, 22);
            this.yInput.TabIndex = 21;
            // 
            // xInput
            // 
            this.xInput.Location = new System.Drawing.Point(64, 44);
            this.xInput.Name = "xInput";
            this.xInput.Size = new System.Drawing.Size(100, 22);
            this.xInput.TabIndex = 20;
            // 
            // yLabel
            // 
            this.yLabel.AutoSize = true;
            this.yLabel.Location = new System.Drawing.Point(36, 86);
            this.yLabel.Name = "yLabel";
            this.yLabel.Size = new System.Drawing.Size(21, 17);
            this.yLabel.TabIndex = 19;
            this.yLabel.Text = "Y:";
            // 
            // xLabel
            // 
            this.xLabel.AutoSize = true;
            this.xLabel.Location = new System.Drawing.Point(36, 44);
            this.xLabel.Name = "xLabel";
            this.xLabel.Size = new System.Drawing.Size(21, 17);
            this.xLabel.TabIndex = 18;
            this.xLabel.Text = "X:";
            // 
            // setXYBtn
            // 
            this.setXYBtn.Location = new System.Drawing.Point(581, 277);
            this.setXYBtn.Name = "setXYBtn";
            this.setXYBtn.Size = new System.Drawing.Size(74, 23);
            this.setXYBtn.TabIndex = 25;
            this.setXYBtn.Text = "Set (X,Y)";
            this.setXYBtn.UseVisualStyleBackColor = true;
            this.setXYBtn.Click += new System.EventHandler(this.setXYBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 17);
            this.label1.TabIndex = 28;
            this.label1.Text = "Shape:";
            // 
            // shapeTextBox
            // 
            this.shapeTextBox.Location = new System.Drawing.Point(64, 12);
            this.shapeTextBox.Name = "shapeTextBox";
            this.shapeTextBox.Size = new System.Drawing.Size(100, 22);
            this.shapeTextBox.TabIndex = 29;
            // 
            // matTextBoxX
            // 
            this.matTextBoxX.Location = new System.Drawing.Point(996, 54);
            this.matTextBoxX.Name = "matTextBoxX";
            this.matTextBoxX.Size = new System.Drawing.Size(100, 22);
            this.matTextBoxX.TabIndex = 30;
            // 
            // matTextBoxY
            // 
            this.matTextBoxY.Location = new System.Drawing.Point(996, 124);
            this.matTextBoxY.Name = "matTextBoxY";
            this.matTextBoxY.Size = new System.Drawing.Size(100, 22);
            this.matTextBoxY.TabIndex = 31;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1142, 341);
            this.Controls.Add(this.matTextBoxY);
            this.Controls.Add(this.matTextBoxX);
            this.Controls.Add(this.shapeTextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.setXYBtn);
            this.Controls.Add(this.lockStateToolStripStatusLabel);
            this.Controls.Add(this.returnedPointLbl);
            this.Controls.Add(this.sendBtn);
            this.Controls.Add(this.yInput);
            this.Controls.Add(this.xInput);
            this.Controls.Add(this.yLabel);
            this.Controls.Add(this.xLabel);
            this.Controls.Add(this.testerLabel);
            this.Controls.Add(this.focusedPictureBox);
            this.Controls.Add(this.roiPictureBox);
            this.Controls.Add(this.sourcePictureBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.focusedPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roiPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sourcePictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label testerLabel;
        private System.Windows.Forms.PictureBox focusedPictureBox;
        private System.Windows.Forms.PictureBox roiPictureBox;
        private System.Windows.Forms.PictureBox sourcePictureBox;
        private System.Windows.Forms.Label lockStateToolStripStatusLabel;
        private System.Windows.Forms.Label returnedPointLbl;
        private System.Windows.Forms.Button sendBtn;
        private System.Windows.Forms.TextBox yInput;
        private System.Windows.Forms.TextBox xInput;
        private System.Windows.Forms.Label yLabel;
        private System.Windows.Forms.Label xLabel;
        private System.Windows.Forms.Button setXYBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox shapeTextBox;
        private System.Windows.Forms.TextBox matTextBoxX;
        private System.Windows.Forms.TextBox matTextBoxY;
    }
}

